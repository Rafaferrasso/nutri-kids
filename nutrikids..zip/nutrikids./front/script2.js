const btnMenu = document.getElementById('btn-menu');
const barraLateral = document.getElementById('barra-lateral');
const btnVoltar = document.getElementById('btn-voltar');

btnMenu.addEventListener('click', () => {
  barraLateral.style.display = 'block';
});

btnVoltar.addEventListener('click', () => {
  barraLateral.style.display = 'none';
});

function criarComentario(texto) {
  const p = document.createElement('p');
  p.textContent = texto;
  return p;
}

const todasReceitas = document.querySelectorAll('.item-receita');

todasReceitas.forEach((receita) => {
  const btnCurtir = receita.querySelector('.btn-curtir');
  const btnComentar = receita.querySelector('.btn-comentar');
  const areaComentarios = receita.querySelector('.area-comentarios');

  let curtidas = 0;

  btnCurtir.addEventListener('click', () => {
    curtidas++;
    btnCurtir.textContent = `Curtir (${curtidas})`;
    btnCurtir.disabled = true;
    btnCurtir.style.opacity = 0.6;
  });

  btnComentar.addEventListener('click', () => {
    const texto = prompt('Digite seu comentário:');
    if (texto && texto.trim() !== '') {
      const novoComentario = criarComentario(texto.trim());
      areaComentarios.appendChild(novoComentario);
    }
  });
});
