const mysql = require('mysql2');
require('dotenv').config();

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'rafaferrasso10',
    database: 'NutriKids'
});

db.connect(err => {
    if (err) {
        console.error('Erro ao conectar no banco de dados:', err);
        console.error('Verifique se o servidor MySQL está rodando e as credenciais estão corretas.');
        return;
    }
    console.log('Conectado ao banco de dados MySQL');
});

module.exports = db
